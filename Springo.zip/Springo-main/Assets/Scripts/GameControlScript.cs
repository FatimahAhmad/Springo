using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameControlScript : MonoBehaviour
{
    public GameOverScreen GameOverScreen;

 
     void OnCollisionEnter(Collision cl ){
        if(cl.collider.tag=="End"){
         Debug.Log("We hit smthing");   
         GameOverScreen.setup();    
        
    }
}
}
