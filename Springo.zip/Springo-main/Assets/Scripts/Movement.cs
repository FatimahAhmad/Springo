using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class Movement : MonoBehaviour
{
    public float moveSpeed;
    public float moveUp;
    public float Speed;
    public Rigidbody rb;
    public Vector2 movement;
    public Transform t3;
    public Slider energyBar;
    

    // Start is called before the first frame update
    void Start()
    {

    rb=this.GetComponent<Rigidbody>();

    }

    // Update is called once per frame
    void Update()
    {
        movement=new Vector2(moveSpeed,moveUp);
    }

    public void FixedUpdate(){

        TouchMove();
    }

    void TouchMove(){

        if(Input.GetMouseButton(0)){
            
            if(energyBar.value>50){
            //transform.Translate(-moveSpeed,moveUp,0);
            rb.velocity = movement * Speed;
            }
            //getMouseButtonup
            //AddForce
            //empty game obj
            //rb.AddForce(5,0,0)  
           // rb.MovePosition((Vector2)transform.position + (movement*Speed*Time.deltaTime));
        }
    }
}