using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Jump : MonoBehaviour
{
    Rigidbody rigidBody;
    SelfCorrector selfCorrector;


    [SerializeField] SpringJoint footSpring;
    [SerializeField] float compressForce;
    [SerializeField] Transform jumpDirection;
    [SerializeField] Transform compressDirection;
    [SerializeField] float baseJumpForce;
    [SerializeField] float maxJumpForce;
    [SerializeField] float jumpForceIncrement;
    [SerializeField] float colorIncrement;
    [SerializeField] float colorDecrement;
    [SerializeField] Material bodyMaterial;

    [SerializeField] private float jumpForce;
    // Start is called before the first frame update
    void Start()
    {
        rigidBody = footSpring.transform.GetComponent<Rigidbody>();
        selfCorrector = footSpring.connectedBody.GetComponent<SelfCorrector>();

        jumpForce = baseJumpForce;
    }

    // Update is called once per frame
    void Update()
    {
        if (!SelfCorrector.landed)
        {
            if (Input.GetMouseButton(0))
            {
                rigidBody.velocity = compressDirection.up * compressForce;

                jumpForce = Mathf.Lerp(jumpForce, maxJumpForce, jumpForceIncrement);

                bodyMaterial.color = Color.Lerp(bodyMaterial.color, Color.red, colorIncrement);
            }
            else if (Input.GetMouseButtonUp(0))
            {

                rigidBody.AddForce(jumpDirection.up * jumpForce);

                selfCorrector.PostJump();

                jumpForce = baseJumpForce;

                StartCoroutine(Relax());

            }
        }
    }


    IEnumerator Relax()
    {
        while (bodyMaterial.color != Color.white)
        { 
            yield return new WaitForFixedUpdate();
            bodyMaterial.color = Color.Lerp(bodyMaterial.color, Color.white, colorDecrement);
            
        } 
    }

}
