using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SelfCorrector : MonoBehaviour
{


    private bool offGround = false;
    public static bool landed = false;

    [SerializeField] Rigidbody rigidBody;

    [SerializeField] float correctionSpeed;
    [SerializeField] float height;
   

    // Update is called once per frame
    void FixedUpdate()
    {
        if (landed)
        { 
            rigidBody.velocity = (transform.position + Vector3.up * height - rigidBody.transform.position).normalized * correctionSpeed;
            Debug.Log("Correcting");

        }

    }

    public void PostJump()
    {
        StartCoroutine(PostJumpUtil());
        Debug.Log("Jumped");
    }
    IEnumerator PostJumpUtil()
    {
        yield return new WaitForSeconds(0.2f);

        offGround = true;
        Debug.Log("Off Ground");
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (offGround)
        {
            
            offGround = false;
            StartCoroutine(StandStraight());

            Debug.Log("Landed");
        }
    }

    IEnumerator StandStraight()
    {
        yield return new WaitForSeconds(0.2f);
        landed = true;
        yield return new WaitForSeconds(0.5f);

        landed = false;
        rigidBody.velocity = Vector3.zero;
        rigidBody.angularVelocity = Vector3.zero;
        Debug.Log("Done Straightening");
    }

    private void OnDrawGizmos()
    {
        Gizmos.DrawCube(transform.position + Vector3.up * height, new Vector3(0.1f, 0.1f, 0.1f));
        Gizmos.DrawCube(rigidBody.transform.position, new Vector3(0.1f, 0.1f, 0.1f));
    }
}
